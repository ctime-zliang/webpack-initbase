import React, { useContext } from 'react'
import { MainStoreContext } from '../../store/Main'

export function TitleView(): React.ReactElement {
	console.log(`Component: TitleView`)
	const { useStore } = useContext(MainStoreContext)
	const { infoStore } = useStore()
	const inputInputAction = (e: React.FormEvent<HTMLInputElement>): void => {
		const inputElement: HTMLInputElement = e.target as HTMLInputElement
		console.log(infoStore)
		infoStore.title = inputElement.value
	}
	return (
		<div>
			<label>Title: </label>
			<input type="text" value={infoStore.title} onChange={inputInputAction} />
		</div>
	)
}
