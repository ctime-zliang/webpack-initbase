import { createContext } from 'react'
import { create } from 'zustand'
import { AttrStore } from './Attr'
import { InfoStore } from './Info'

export async function createStoreInstance(): Promise<any> {
	const useStore = create((set: any, get: any): any => {
		const storeInstance: MainStore = new MainStore(set, get)
		return storeInstance
	})
	return { useStore }
}

export class MainStore {
	public zustandSet: any
	public zustandGet: any
	public infoStore: InfoStore
	public attrStore: AttrStore
	constructor(zustandSet: any, zustandGet: any) {
		this.zustandSet = zustandSet
		this.zustandGet = zustandGet
		this.infoStore = new InfoStore(this)
		this.attrStore = new AttrStore(this)
	}

	public async initial(): Promise<void> {
		/* ... */
	}

	public whenMouned(): void {
		console.log(`The module has mounted.`)
	}

	public whenUnmount(): void {
		console.log(`The module has unmounted.`)
	}
}

export const MainStoreContext = createContext<{ useStore: any }>(null!)
