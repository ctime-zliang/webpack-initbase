import React, { useLayoutEffect, useRef, useState } from 'react'
import { Main } from './main'
import { createStoreInstance, MainStoreContext } from './store/Main'

function ZustandRoot(): React.ReactElement {
	const [store, setStore] = useState<any>(null!)
	const storeRef: { current: any } = useRef<any>(null!)
	useLayoutEffect((): (() => void) => {
		createStoreInstance().then((useStore: any): void => {
			setStore(useStore)
			storeRef.current = useStore
		})
		return (): void => {}
	}, [])
	if (!store) {
		return <section>store initialing...</section>
	}
	return (
		<section>
			<MainStoreContext.Provider value={store}>
				<Main />
			</MainStoreContext.Provider>
		</section>
	)
}
export default React.memo(ZustandRoot)
