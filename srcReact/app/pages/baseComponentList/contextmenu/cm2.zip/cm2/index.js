import './index.css'
import React, { useLayoutEffect, useRef } from 'react'
import PropTypes from 'prop-types'

import { useOnClickOutside } from './useOnClickOutside'

function MenuSeparator({ item }) {
	return <li className={'menu-separator' + (item.className ? ` ${item.className}` : '')} />
}
function MenuItem({ item, createSubmenu = false }) {
	return (
		<li className={'menu-item' + (createSubmenu ? ' submenu' : '') + (item.className ? ` ${item.className}` : '')} data-data={item.data}>
			<button type="button" className="menu-btn">
				<span className="fa" icon={item.icon ? item.icon : 'circle'}>
					*
				</span>
				<span className="menu-text">{item['title']}</span>
			</button>
			{createSubmenu && createSubmenu(item['submenu'], true)}
		</li>
	)
}

export default function ContextMenu(props) {
	const { visible, hideMenu, pageXY, items, callbackOnClickMenu, className, ...rest } = props

	let menuElem = useRef(null)
	useOnClickOutside(menuElem, hideMenu)

	useLayoutEffect(() => {
		//console.log('useEffect', menuElem.current, props);

		if (!menuElem.current) return

		const widthWindow = document.documentElement.clientWidth
		const heightWindow = document.documentElement.clientHeight

		function checkOutWindow(checkedElement, isRootMenu = false) {
			if (!isRootMenu) {
				checkedElement.classList.remove('menuRight')
				checkedElement.classList.add('menuLeft')
				checkedElement.classList.remove('menuBottom')
				checkedElement.classList.add('menuTop')
			}

			const coordsCheckedElement = checkedElement.getBoundingClientRect()

			if (widthWindow < coordsCheckedElement.x + coordsCheckedElement.width) {
				if (isRootMenu) checkedElement.style.left = widthWindow - coordsCheckedElement.width + 'px'

				if (!isRootMenu) {
					checkedElement.classList.add('menuRight')
					checkedElement.classList.remove('menuLeft')
				}
			}
			if (heightWindow < coordsCheckedElement.y + coordsCheckedElement.height) {
				if (isRootMenu) checkedElement.style.top = heightWindow - coordsCheckedElement.height + 'px'

				if (!isRootMenu) {
					checkedElement.classList.add('menuBottom')
					checkedElement.classList.remove('menuTop')
				}
			}
		}

		// correction of the position of the root menu, if it is outside the window
		checkOutWindow(menuElem.current, true)

		// correction of the position of the submenus, if it is outside the window
		let submenus = Array.from(document.querySelectorAll('menu')).slice(1)
		submenus.forEach(submenu => {
			checkOutWindow(submenu, false)
		})
	})

	function onClickMenu(event) {
		let parentLiElem = event.target.closest('li.menu-item:not(.submenu)')
		if (parentLiElem) {
			callbackOnClickMenu(event, parentLiElem.dataset.data)
			hideMenu()
		}
	}

	function createMenu(arrMenuItem, submenu = false) {
		return (
			<menu
				ref={submenu ? null : menuElem}
				className={submenu ? 'menu' : 'menu show-menu ' + (className ? className : '')}
				style={submenu ? null : { left: pageXY[0], top: pageXY[1] }}
				onClick={submenu ? null : e => onClickMenu(e)}
			>
				{arrMenuItem.map((item, i) => {
					if (item['type'] === 'item') return <MenuItem key={i} item={item} />

					if (item['type'] === 'separator') return <MenuSeparator key={i} item={item} />

					if (item['type'] === 'submenu') return <MenuItem key={i} item={item} createSubmenu={createMenu} />

					return <div key={i}>{item['type']}</div>
				})}
			</menu>
		)
	}

	return visible ? (
		<div className="react-contextmenu" {...rest}>
			{createMenu(items)}
		</div>
	) : null
}
