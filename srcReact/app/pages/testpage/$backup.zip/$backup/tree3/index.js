/***
 * 2022-01-11
 * 将 tree组件独立出来
 */
import Tree from './Tree'
export default Tree
