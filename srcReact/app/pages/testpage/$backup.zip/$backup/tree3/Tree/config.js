let config = {
	rowDefaultHeight: 30, //列的默认高度
	bufferScale: 1, //数据缓存比例
}
export default config
