export type TVariableHeightListCallProps = {
    containerHeight: number
    countTotal: number
    estimatedRowHeight: number
    bufferSize?: number
    topBufferSize?: number
    bottomBufferSize?: number
}

export type TVariableHeightListProps = TVariableHeightListCallProps & {
    bufferSize: number
    topBufferSize: number
    bottomBufferSize: number
    rowCache: Array<TRowCache>
}

export type TRowCache = {
    index: number
    top: number
    bottom: number
    height: number
    itemData: any
}