import { TVariableHeightListProps } from "../types/types";

export const defaultProfile: TVariableHeightListProps = {
    containerHeight: 0,
    countTotal: 0,
    estimatedRowHeight: 20,
    bufferSize: 10,
    topBufferSize: 10,
    bottomBufferSize: 10,
    rowCache: []
}