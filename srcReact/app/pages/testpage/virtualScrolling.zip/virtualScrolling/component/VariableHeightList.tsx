import React, { useEffect, useMemo, useRef, useState } from "react";
import { defaultProfile } from "../config/config";
import { TRowCache, TVariableHeightListCallProps, TVariableHeightListProps } from "../types/types";
import { initRowCache } from "../utils/updateRowCache";

function VariableHeightList(props: TVariableHeightListCallProps): React.ReactElement {
    const globalProfile: TVariableHeightListProps = { ...defaultProfile, ...props }
    const { estimatedRowHeight, topBufferSize, bufferSize, countTotal } = globalProfile
    const containerElementRef = useRef<HTMLDivElement>(null)
    const scrollPhantomElementRef = useRef<HTMLDivElement>(null)
    const contentWrapperElementRef = useRef<HTMLDivElement>(null)
    const [insCountTotal, setInsCountTotal] = useState<number>(countTotal)
    const [containerScrollTop, setContainerScrollTop] = useState<number>(0)
    const [verticalSizeInViewport, setVerticalSizeInViewport] = useState<number>(Math.ceil(globalProfile.containerHeight / globalProfile.estimatedRowHeight))
    const [originStartIndex, setOriginStartIndex] = useState<number>(0)
    const [originEndIndex, setOriginEndIndex] = useState<number>(0)
    const [renderStartIndex, setRenderStartIndex] = useState<number>(0)
    const [renderEndIndex, setRenderEndIndex] = useState<number>(Math.min(originStartIndex + verticalSizeInViewport + bufferSize, countTotal - 1))
    const [scrollPhantomElementHeight, setScrollPhantomElementHeight] = useState<number>(estimatedRowHeight * countTotal)
    
    globalProfile.rowCache = useMemo((): Array<TRowCache> => {
        return initRowCache(estimatedRowHeight, countTotal, globalProfile.rowCache)
    }, [countTotal])

    useEffect((): void => {
        if (insCountTotal !== countTotal) {
            setInsCountTotal(countTotal)
            setOriginStartIndex(0)
            setRenderStartIndex(0)
            setRenderEndIndex(Math.min(originStartIndex + verticalSizeInViewport + bufferSize, countTotal - 1))
            setScrollPhantomElementHeight(estimatedRowHeight * insCountTotal)
            setContainerScrollTop(0)
            if (containerElementRef.current) {
                containerElementRef.current.scrollTop = 0
            }
        }
    }, [countTotal])

    return (<></>)
}