import { TRowCache } from "../types/types";

export function initRowCache(estimatedRowHeight: number, countTotal: number, rowCache: Array<TRowCache>): Array<TRowCache> {
    rowCache.length = 0
    for (let i: number = 0; i < countTotal; i++) {
        rowCache[i] = {
            index: i,
            height: estimatedRowHeight,
            top: i * estimatedRowHeight,
            bottom: (i + 1) * estimatedRowHeight,
            itemData: 0,
        }
    }
    return [...rowCache]
}

export function updateRowCacheByContentItemElement(children: Array<HTMLElement>, rowCache: Array<TRowCache): void {
    children.forEach((element: HTMLElement): void => {
        if (!element) {
            // scroll too fast?...
            return
        }
        const rect = element.getBoundingClientRect()
        const { height } = rect
        const index = Number(node.id.split('-')[1])
        const oldHeight = this.cachedPositions[index].height
        const dValue = oldHeight - height

        if (dValue) {
            this.cachedPositions[index].bottom -= dValue
            this.cachedPositions[index].height = height
            this.cachedPositions[index].dValue = dValue
        }
    })
}