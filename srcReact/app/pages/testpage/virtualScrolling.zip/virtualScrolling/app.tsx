import Vlist from './_VariableHeightList'
import React from 'react'

export function getRandomInArea(min = 0, max = Number.MAX_SAFE_INTEGER) {
	return Math.floor(Math.random() * (max - min + 1)) + min
}

const data = []
const dataLength = 10000
for (let id = 0; id < dataLength; ++id) {
	data.push({
		id,
		value: (function () {
			const len = getRandomInArea(200, 500)
			return Array(len).fill('0').join(' ')
		})(),
	})
}

const userVisibleHeight = 400
const estimateRowHeight = 20
const bufferSize = 5

export default function dummyComp() {
	return (
		<Vlist
			height={userVisibleHeight}
			total={dataLength}
			estimateRowHeight={estimateRowHeight}
			bufferSize={bufferSize}
			rowRenderer={(index: number, styleData: any) => {
				const item = index
				return (
					<div
						key={item}
						style={styleData}
						onClick={() => {
							console.log('item-', index)
						}}
						id={`item-${index}`}
					>
						<span>Item - {data[index].id} Data:</span>
						<span>{data[index].value}</span>
					</div>
				)
			}}
		/>
	)
}
